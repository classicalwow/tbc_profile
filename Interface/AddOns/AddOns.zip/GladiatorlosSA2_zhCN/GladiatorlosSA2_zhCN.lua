
local GSA = GladiatorlosSA
rawset (GSA.GSA_LANGUAGE, "GladiatorlosSA2_zhCN\\Voice_zhCN", "VV")
rawset (GSA.GSA_LOCALEPATH, "zhCN", "GladiatorlosSA2_zhCN\\Voice_zhCN")
