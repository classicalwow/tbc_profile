# RestedXP Guides

## [v4.3.2](https://github.com/RestedXP/RXPGuides/tree/v4.3.2) (2022-09-21)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.3.1...v4.3.2) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Add missing AceDBOptions include for profile use