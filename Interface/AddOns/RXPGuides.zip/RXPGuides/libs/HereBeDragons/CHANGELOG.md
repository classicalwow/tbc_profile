# Lib: HereBeDragons

## [2.08-release](https://github.com/Nevcairiel/HereBeDragons/tree/2.08-release) (2022-02-23)
[Full Changelog](https://github.com/Nevcairiel/HereBeDragons/compare/2.07-release...2.08-release) [Previous Releases](https://github.com/Nevcairiel/HereBeDragons/releases)

- Update TOC  
- Move Load-on-Demand update to after all functions are parsed  
    Fixes #12  
- Increase the max map ID to accomodate for all new 9.1 zones  
    Bump it up to 2500 to allow for some growth in 9.x and possibly 10.x  
    Fixes #13  
- Update TOC for 9.1  
